package thirdpartyone.endpoints;

public class Endpoints {
    public static final String baseUrl = "https://jsonplaceholder.typicode.com";
}
