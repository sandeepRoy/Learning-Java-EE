package dispose_demo.controllers;

import dispose_demo.models.Greet;
import dispose_demo.models.User;
import dispose_demo.producers.GreetProducer;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@Path("/user")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UserController {
    @Inject
    GreetProducer greetProducer;

    private User saved_user;

    @GET
    @Path("/greet/{username}")
    public Response hitGreetProducer(@PathParam("username") String username) {
        Greet user = greetProducer.greetUser(username);
        String greet = user.greet();
        saved_user = (User )user;
        return Response.status(Response.Status.OK).entity(greet + " " + user.hashCode()).build();
    }

    @GET
    @Path("/dispose/{username}")
    public Response hitDisposer(@PathParam("username") String username) {
        if(saved_user.getName() == username) {
            greetProducer.dispose(saved_user);
            return Response.status(Response.Status.OK).entity(username).build();
        }
        else{
            return Response.status(Response.Status.OK).entity("Can't Find User!").build();
        }
    }
}
