package dispose_demo.models;

public interface Greet {
    String greet();
}
