package dispose_demo.models;

import dispose_demo.qualifier.UserQualifier;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@UserQualifier
@ApplicationScoped
@Named("saved_user")
public class User implements Greet {
    private String name;

    @Override
    public String greet() {
        return "Hello " + name;
    }
}
