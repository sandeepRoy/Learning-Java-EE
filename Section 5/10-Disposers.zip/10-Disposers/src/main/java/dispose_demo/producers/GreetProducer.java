package dispose_demo.producers;

import dispose_demo.models.Greet;
import dispose_demo.models.User;
import dispose_demo.qualifier.UserQualifier;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import jakarta.enterprise.inject.Disposes; // use this for Produces and Disposes
import jakarta.inject.Inject;

@ApplicationScoped
public class GreetProducer {

    @Inject
    private User saved_user;

    @Produces
    @UserQualifier
    public Greet greetUser(String username) {
        System.out.println("12 : Greet Producer");
        saved_user = new User();
        saved_user.setName(username);
        return saved_user;
    }

    public void dispose(@Disposes User user) { // Try with Child class
        // Dispose of the Greet bean if necessary
        saved_user = null;
        System.out.println("The is deleted.");
    }
}
