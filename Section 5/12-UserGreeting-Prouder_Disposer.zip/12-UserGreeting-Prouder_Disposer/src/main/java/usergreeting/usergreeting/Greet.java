package usergreeting.usergreeting;

public interface Greet {
    String greet();
}
