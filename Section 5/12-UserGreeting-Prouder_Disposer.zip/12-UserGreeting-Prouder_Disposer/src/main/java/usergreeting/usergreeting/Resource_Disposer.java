package usergreeting.usergreeting;

import jakarta.inject.Inject;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;

@Path("/resource")
public class Resource_Disposer {
    @Inject
    private Service service;

    @POST
    @Path("/dispose")
    public Response disposeUser() {

        try {
            // User created using CDI @Prdducer
            User user = service.createUser();

            // Manually disposing, through @Disposer
            service.disposeUserManually(user);

            return Response.ok("Disposed").build();
        } catch (Exception e) {
            return Response.serverError().entity("Error Disposing User").build();
        }
    }
}
