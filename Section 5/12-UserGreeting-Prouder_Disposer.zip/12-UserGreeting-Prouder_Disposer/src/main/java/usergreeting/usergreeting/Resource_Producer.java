package usergreeting.usergreeting;

import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;

@Path("/user")
public class Resource_Producer {

    @Inject
    private User user;

    @GET
    @Path("/produce")
    public Response produceUser() {
        String greet = user.greet();
        int hashcode = user.hashCode();
        return Response.ok(greet + " " + hashcode).build();
    }
}
