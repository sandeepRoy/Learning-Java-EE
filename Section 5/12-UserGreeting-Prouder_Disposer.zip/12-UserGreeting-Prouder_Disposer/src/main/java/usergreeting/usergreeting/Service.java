package usergreeting.usergreeting;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Disposes;
import jakarta.enterprise.inject.Produces;

@ApplicationScoped
public class Service {

    @Produces
    public User createUser() {
        return new User("Sandeep Roy");
    }

    public void disposeUser(@Disposes User user) {
        System.out.println("Disposing User: " + user.getName());
    }

    public String disposeUserManually(User user) {
        disposeUser(user);
        return "Disposed";
    }
}
