package com.example.crudtest1;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class HelloApplication extends Application {

}


// Getting Started: Rinse and Repeat Edit this file, Separate projects for OrderRepository, Inject that OrderRepository EJB in test class.
