package com.example.crudtest1.service;

import com.example.crudtest1.entity.Student;
import com.example.crudtest1.entity.Student_;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.weld.environment.se.Weld;
import org.jboss.weld.environment.se.WeldContainer;
import org.junit.*;
import org.junit.runner.RunWith;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.*;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;

@RunWith(Arquillian.class)
public class StudentServiceTest {

    @Deployment
    public static JavaArchive createDeployment() {

        JavaArchive jar = ShrinkWrap.create(JavaArchive.class)
                .addClass(StudentService.class)
                .addAsManifestResource(EmptyAsset.INSTANCE, "beans.xml");
        System.out.println(jar.toString(true));

        return jar;
    }

    static EntityManager em;
    static Weld weld;
    WeldContainer weldContainer;


    @BeforeClass
    public static void init() {
        weld = new Weld();
        WeldContainer container = weld.initialize();
    }

    @AfterClass
    public static void close() throws Exception {
        weld.shutdown();
    }

    @Before
    public void before() throws Exception {
        em = Persistence.createEntityManagerFactory("h2-persistence-unit").createEntityManager();
    }

    @Test
    public void shouldReturnZeroBeforeAddingStudent() {
        List<Student> students = em.createQuery("select student from Student student", Student.class).getResultList();
        System.out.println("EntityManager At: " + em.toString());
        System.out.println("71: " + students.size());
        assertEquals(students.size(), 0);
    }

    @Test
    public void shouldCreateStudent() {

        String student_name = "Sandeep Roy";
        Student student = Student.builder().student_name(student_name).build();
        em.persist(student);

        System.out.println("EntityManager At: " + em.toString());
        System.out.println("81: " + student.toString());
        assertEquals(student_name, student.getStudent_name());
    }

    @Test
    public void shouldReturnAllStudentsCount() {
        List<Student> students = em.createQuery("select student from Student student", Student.class).getResultList();

        System.out.println("EntityManager At: " + em.toString());
        System.out.println("87: " + students.size());
        assertEquals(students.size(), 1);
    }

}