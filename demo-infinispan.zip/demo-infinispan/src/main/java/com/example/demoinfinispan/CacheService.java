package com.example.demoinfinispan;

import org.infinispan.Cache;
import org.infinispan.manager.EmbeddedCacheManager;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;

import javax.naming.InitialContext;
import javax.naming.NamingException;

@Singleton
@Startup
public class CacheService {

    private Cache<String, String> cache; // Replace <String, String> with your key-value types if needed

    @PostConstruct
    public void init() {
        try {
            // Lookup for the EmbeddedCacheManager provided by WildFly
            InitialContext ctx = new InitialContext();
            EmbeddedCacheManager cacheManager = (EmbeddedCacheManager) ctx.lookup("java:jboss/infinispan/container/hibernate");

            // Get the named cache (e.g., "entity" from standalone.xml)
            this.cache = cacheManager.getCache("entity");
            System.out.println("Cache initialized successfully.");
        } catch (NamingException e) {
            throw new RuntimeException("Failed to initialize cache manager.", e);
        }
    }

    public void put(String key, String value) {
        cache.put(key, value);
        System.out.println("Added to cache: " + key + " -> " + value);
    }

    public String get(String key) {
        String value = cache.get(key);
        System.out.println("Retrieved from cache: " + key + " -> " + value);
        return value;
    }

    public void remove(String key) {
        cache.remove(key);
        System.out.println("Removed from cache: " + key);
    }

    @PreDestroy
    public void cleanup() {
        if (cache != null) {
            cache.stop(); // Stop the cache to free up resources
        }
    }
}
