/**
 * Contains general exception classes thrown in the project.
 * <p>
 * Every project-specific exceptions should be located in this package.
 * </p>
 */
package com.nilhcem.fakesmtp.core.exception;
