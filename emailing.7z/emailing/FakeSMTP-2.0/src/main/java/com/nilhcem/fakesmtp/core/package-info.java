/**
 * Provides core methods to get the configuration of the project or i18n messages.
 */
package com.nilhcem.fakesmtp.core;
