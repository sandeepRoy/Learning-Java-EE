/**
 * Provides the main GUI components (main JFrame, JPanel, MenuBar...).
 */
package com.nilhcem.fakesmtp.gui;
