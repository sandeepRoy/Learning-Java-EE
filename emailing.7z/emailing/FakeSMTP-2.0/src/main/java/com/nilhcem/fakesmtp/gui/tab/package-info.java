/**
 * Provides all the GUI components in the tabbed pane.
 */
package com.nilhcem.fakesmtp.gui.tab;
