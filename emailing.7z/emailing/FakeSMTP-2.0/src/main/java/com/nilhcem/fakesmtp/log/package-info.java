/**
 * Provides a Logback appender and an observable object to redirect logs to the GUI.
 */
package com.nilhcem.fakesmtp.log;
