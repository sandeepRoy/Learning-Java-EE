/**
 * Models used in the application to contain emails or component fields information.
 */
package com.nilhcem.fakesmtp.model;
