/**
 * Entry point of the application.
 */
package com.nilhcem.fakesmtp;
