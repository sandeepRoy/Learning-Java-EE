/**
 * Provides services classes for the SMTP server.
 */
package com.nilhcem.fakesmtp.server;
