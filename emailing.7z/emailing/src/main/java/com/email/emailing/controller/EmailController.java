package com.email.emailing.controller;

import com.email.emailing.service.EmailService;
import jakarta.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RestController
@RequestMapping("/email")
public class EmailController {

    @Autowired
    public EmailService emailService;

    @PostMapping("/send")
    public String sendEmail(
            @RequestParam String to,
            @RequestParam String subject,
            @RequestParam String body,
            @RequestParam MultipartFile attachment
            ) throws IOException, MessagingException {
        File file = convertMultipartFileToFile(attachment);
        emailService.sendEmail(to, subject, body, file);

        if(file.exists()) {
            file.delete();
        }

        return "Email Sent!";
    }

    public File convertMultipartFileToFile(MultipartFile file) throws IOException {
        File tempFile = File.createTempFile(file.getOriginalFilename(), ".tmp");
        file.transferTo(tempFile);
        return tempFile;
    }
}
