package com.email.emailing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailingApplicationTests {

	@Test
	void contextLoads() {
	}

}
