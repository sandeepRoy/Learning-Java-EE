package com.example.demoinfinispan;

import org.infinispan.manager.DefaultCacheManager;
import java.io.IOException;

public class CacheConfigLoader {
    public static DefaultCacheManager loadCacheConfig() throws IOException {
        return new DefaultCacheManager("infinispan.xml");  // ✅ Directly loads from classpath
    }
}
