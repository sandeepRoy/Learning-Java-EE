package com.example.demoinfinispan;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.annotation.Resource;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import org.infinispan.Cache;
import org.infinispan.configuration.cache.Configuration;
import org.infinispan.configuration.cache.ConfigurationBuilder;
import org.infinispan.manager.CacheContainer;
import org.infinispan.manager.DefaultCacheManager;

/*
* Loading cache configuration from infinispan.xml
* */

@Singleton
@Startup
public class CacheService1 {

    private Cache<String, String> customCache; // loading existing cache, [works]
    private Cache<String, String> runtimeCache; // creating new cache [works]

    // Same behaviour replicated on standalone-full.xml ? Yes

    private DefaultCacheManager defaultCacheManager;


    @PostConstruct
    public void init() {
        try {
            defaultCacheManager = CacheConfigLoader.loadCacheConfig();

            Configuration newCacheConfig = new ConfigurationBuilder()
                    .memory().size(100)
                    .build();

            this.customCache = defaultCacheManager.getCache("custom-cache");
            defaultCacheManager.defineConfiguration("runtimeCache", newCacheConfig);
            runtimeCache = defaultCacheManager.getCache("runtimeCache");

        } catch (Exception e) {
            throw new RuntimeException("Failed to load cache configuration", e);
        }
    }

    public void put(String key, String value) {
        System.out.println("Using Cache : " + runtimeCache.getName());
        runtimeCache.put(key, value);
        System.out.println("Added to cache: " + key + " -> " + value);
    }

    public String get(String key) {
        System.out.println("Using Cache : " + runtimeCache.getName());
        String value = (String) runtimeCache.get(key);
        System.out.println("Retrieved from cache: " + key + " -> " + value);
        return value;
    }

    public void remove(String key) {
        runtimeCache.remove(key);
        System.out.println("Removed from cache: " + key);
    }

    @PreDestroy
    public void cleanup() {
        if(runtimeCache != null) {
            runtimeCache.stop();
        }
    }
}
