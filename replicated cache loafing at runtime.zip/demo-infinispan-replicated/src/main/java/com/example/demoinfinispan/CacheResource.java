package com.example.demoinfinispan;

import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;

@Path("/cache")
public class CacheResource {

    @Inject
    private CacheServiceReplicated cacheService;

    @POST
    @Path("/put")
    public String put(@QueryParam("key") String key, @QueryParam("value") String value) {
        cacheService.put(key, value);
        return "Added " + key + " -> " + value;
    }

    @GET
    @Path("/get")
    public String get(@QueryParam("key") String key) {
        String value = cacheService.get(key);
        return value == null ? "Key not found: " + key : key + " -> " + value;
    }

    @POST
    @Path("/remove")
    public String remove(@QueryParam("key") String key) {
        cacheService.remove(key);
        return "Removed key: " + key;
    }
}
