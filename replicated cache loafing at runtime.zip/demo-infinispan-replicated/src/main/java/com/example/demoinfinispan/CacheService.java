//package com.example.demoinfinispan;
//
//import jakarta.annotation.Resource;
//import org.infinispan.Cache;
//import org.infinispan.configuration.cache.ConfigurationBuilder;
//import org.infinispan.manager.EmbeddedCacheManager;
//import jakarta.annotation.PostConstruct;
//import jakarta.annotation.PreDestroy;
//import jakarta.ejb.Singleton;
//import jakarta.ejb.Startup;
//
//import javax.naming.InitialContext;
//import javax.naming.NamingException;
//
//@Singleton
//@Startup
//public class CacheService {
//
//    @Resource(lookup = "java:jboss/infinispan/container/hibernate")
//    private EmbeddedCacheManager cacheManager;
//
//    private Cache<String, String> customCache;
//    private Cache<String, String> entityCache;
//
////    @PostConstruct
////    public void init() {
////        try {
////            // Lookup for the EmbeddedCacheManager provided by WildFly
////            InitialContext ctx = new InitialContext();
////            EmbeddedCacheManager cacheManager = (EmbeddedCacheManager) ctx.lookup("java:jboss/infinispan/container/hibernate");
////
////            // Get the named cache (e.g., "entity" from standalone.xml)
////            this.cache = cacheManager.getCache("entity");
////            System.out.println("Cache initialized successfully.");
////        } catch (NamingException e) {
////            throw new RuntimeException("Failed to initialize cache manager.", e);
////        }
////    }
//
//    @PostConstruct
//    public void init() {
//        cacheManager.createCache("custom-cache", new ConfigurationBuilder().build());
//        customCache = cacheManager.getCache("custom-cache");
//        entityCache = cacheManager.getCache("entity");
//    }
//
//    public void put(String key, String value) {
//        // cacheManager.getCache("entity").put(key, value);
//        customCache.put(key, value);
//        System.out.println("Added to cache: " + key + " -> " + value);
//    }
//
//    public String get(String key) {
//        // String value = (String) cacheManager.getCache("entity").get(key);
//        String value = (String) customCache.get(key);
//        System.out.println("Retrieved from cache: " + key + " -> " + value);
//        return value;
//    }
//
//    public void remove(String key) {
//        // cacheManager.getCache("entity").remove(key);
//        customCache.remove(key);
//        System.out.println("Removed from cache: " + key);
//    }
//
//    @PreDestroy
//    public void cleanup() {
////        if (cacheManager.getCache("entity") != null) {
////            cacheManager.getCache("entity").stop(); // Stop the cache to free up resources
////        }
//        if(customCache != null) {
//            customCache.stop();
//        }
//    }
//}
