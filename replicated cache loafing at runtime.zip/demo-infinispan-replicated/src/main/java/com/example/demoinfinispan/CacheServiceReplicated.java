package com.example.demoinfinispan;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import org.infinispan.Cache;
import org.infinispan.configuration.cache.Configuration;
import org.infinispan.configuration.cache.ConfigurationBuilder;
import org.infinispan.manager.DefaultCacheManager;

/*
* Loading cache configuration from infinispan.xml
* */

@Singleton
@Startup
public class CacheServiceReplicated {

    private Cache<String, String> existingCache;                                                         // loading existing cache, [?]
    // private Cache<String, String> runtimeCache;                                                       // creating new cache [?]
                                                                                                         // Same behaviour replicated on standalone-full-ha.xml ?
    private DefaultCacheManager defaultCacheManager;

    @PostConstruct
    public void init() {
        try {
            // Step 1: Use the new ReplicatedCacheManager
            defaultCacheManager = ReplicatedCacheManager.createReplicatedCacheManager();

            // Step 2: Get the replicated cache
            existingCache = defaultCacheManager.getCache("replicated-cache");

            System.out.println("✅ Cache Loaded: " + existingCache.getName());
        } catch (Exception e) {
            throw new RuntimeException("Failed to load cache configuration", e);
        }
    }

    public void put(String key, String value) {
        System.out.println("Using Cache : " + existingCache.getName());
        existingCache.put(key, value);
        System.out.println("Added to cache: " + key + " -> " + value);
    }

    public String get(String key) {
        System.out.println("Using Cache : " + existingCache.getName());
        String value = (String) existingCache.get(key);
        System.out.println("Retrieved from cache: " + key + " -> " + value);
        return value;
    }

    public void remove(String key) {
        existingCache.remove(key);
        System.out.println("Removed from cache: " + key);
    }

    @PreDestroy
    public void cleanup() {
        if(existingCache != null) {
            existingCache.stop();
        }
    }
}
