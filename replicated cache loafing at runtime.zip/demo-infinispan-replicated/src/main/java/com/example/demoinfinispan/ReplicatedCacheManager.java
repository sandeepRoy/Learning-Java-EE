package com.example.demoinfinispan;

import org.infinispan.configuration.cache.*;
import org.infinispan.configuration.global.*;
import org.infinispan.manager.DefaultCacheManager;
import org.jgroups.JChannel;

public class ReplicatedCacheManager {

    public static DefaultCacheManager createReplicatedCacheManager() throws Exception {
        // 🔹 Step 1: Load JGroups for clustering
        JChannel channel = new JChannel("default-jgroups-tcp.xml");
        channel.connect("ReplicatedCacheCluster"); // Cluster name

        // 🔹 Step 2: Configure Infinispan to use clustering
        GlobalConfiguration globalConfig = new GlobalConfigurationBuilder()
                .transport()
                .defaultTransport() // Uses JGroups for networking
                .clusterName("ReplicatedCacheCluster")
                .build();

        // 🔹 Step 3: Create Infinispan cache manager with this config
        DefaultCacheManager cacheManager = new DefaultCacheManager(globalConfig);

        // 🔹 Step 4: Define a Replicated Cache (creates at runtime)
        Configuration replicatedCacheConfig = new ConfigurationBuilder()
                .clustering()
                .cacheMode(CacheMode.REPL_SYNC) // ✅ Makes it a replicated cache
                .build();

        // 🔹 Step 5: Register the cache at runtime
        cacheManager.defineConfiguration("my-replicated-cache", replicatedCacheConfig);

        System.out.println("✅ Replicated Cache Created: my-replicated-cache");
        return cacheManager;
    }
}




