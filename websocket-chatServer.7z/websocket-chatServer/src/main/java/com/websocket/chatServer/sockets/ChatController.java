package com.websocket.chatServer.sockets;

import jakarta.websocket.*;
import jakarta.websocket.server.ServerEndpoint;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

@ServerEndpoint("/chat-server")
public class ChatController {

    private static String path = "D:\\Practice\\Jakarta EE\\Learning\\Section 8\\websocket-chatServer\\src\\main\\java\\com\\websocket\\chatServer\\sockets\\";
    private static String updated_path;
    private static final Logger logger = Logger.getLogger(ChatController.class.getName());
    private static Set<Session> sessionSet = new HashSet<>();
    private static Map<Session, String> usernameMap = new HashMap<>();

    public static File file;
    // onOpen() is called whenever a new Client connects
    @OnOpen
    public void onOpen(Session session) {
        sessionSet.add(session);
        logger.info("New connection: " + session.getId());
        updated_path = path + "//" +session.getId();
        file = new File(updated_path);
        file.mkdirs();

        // Notify all clients about the current list of online users when someone connects
        String userList = "Online Users: " + String.join(", ", usernameMap.values());
        for (Session currentSession : sessionSet) {
            try {
                currentSession.getBasicRemote().sendText(userList);
            } catch (IOException e) {
                logger.severe("Error sending user list: " + e.getMessage());
            }
        }
    }

    // onMessage() is called whenever a client sends a message
    @OnMessage
    public void onMessage(String message, Session session) throws IOException {
        // Check if the message is setting the username
        if (message.startsWith("username:")) {
            String username = message.substring(9).trim();
            usernameMap.put(session, username); // Store the username for the session
            logger.info("User " + username + " set their username.");

            // Send the updated list of online users to all connected clients (only once when username is set)
            String userList = "Online Users: " + String.join(", ", usernameMap.values());
            for (Session currentSession : sessionSet) {
                currentSession.getBasicRemote().sendText(userList);
            }
        } else {
            // Otherwise, it's a chat message
            String username = usernameMap.get(session);
            if (username == null) {
                // Ignore chat messages from users who haven't set a username
                session.getBasicRemote().sendText("Please set your username first!");
                return;
            }

            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            String formattedMessage = username + " (" + timestamp + "): " + message;

            // Write the message to the user's file
            file = new File(  updated_path + "//" + username + ".txt");
            try (FileWriter writer = new FileWriter(file, true)) {
                writer.write(formattedMessage + System.lineSeparator());
                updated_path = path;
            } catch (IOException e) {
                logger.severe("Error writing to file for user " + username + ": " + e.getMessage());
            }

            // Broadcast the chat message to all connected clients, including the sender
            for (Session currentSession : sessionSet) {
                currentSession.getBasicRemote().sendText(formattedMessage);
            }
        }
    }

    // onClose() is called whenever the client disconnects
    @OnClose
    public void onClose(Session session) {
        sessionSet.remove(session);
        String username = usernameMap.remove(session);

        // Notify all clients about the current list of online users after someone disconnects
        String userList = "Online Users: " + String.join(", ", usernameMap.values());
        for (Session currentSession : sessionSet) {
            try {
                currentSession.getBasicRemote().sendText(userList);
            } catch (IOException e) {
                logger.severe("Error sending user list: " + e.getMessage());
            }
        }

        file.delete();
        logger.info("Client disconnected: " + session.getId() + " (" + username + ")");
    }

    // onError() is called whenever an error occurs
    @OnError
    public void onError(Session session, Throwable throwable) {
        logger.severe("Error: " + throwable.getMessage());
    }
}
